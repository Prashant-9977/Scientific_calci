package com.example.calci
import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.widget.Button
import android.widget.TextView

class Welcome : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        supportActionBar?.setTitle("Welcome")
        //supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.GREEN))
        val myTextView = findViewById<TextView>(R.id.myTextView)
        myTextView.text = "JSS ACADEMY OF TECHNICAL EDUCATION"
        val myTextView1=findViewById<TextView>(R.id.myTextView1)
        myTextView1.text="  MAD LAB MINI PROJECT ON"
        val myTextView2=findViewById<TextView>(R.id.myTextView2)
         myTextView2.text="SCIENTIFIC CALCULATOR"
        val myTextView3=findViewById<TextView>(R.id.myTextView3)
        myTextView3.text="  Under the Guidance Of\n       Mrs.Rashmi B N"
        val myTextView4=findViewById<TextView>(R.id.myTextView4)
        val text = "Submitted By:<br>Praddep Hiremath(1JS20CS108)<br>Prashant(1JS20CS112)"
        @Suppress("DEPRECATION")
        myTextView4.text = Html.fromHtml(text)
        val signupBtn=findViewById<Button>(R.id.signupBtn)
        signupBtn.setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
        }
        val loginBtn=findViewById<Button>(R.id.loginBtn)
        loginBtn.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

    }
}