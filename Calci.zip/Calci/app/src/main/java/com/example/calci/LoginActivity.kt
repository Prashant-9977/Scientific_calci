package com.example.calci
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.room.Room
import androidx.room.Room.databaseBuilder
import java.lang.Exception
class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        supportActionBar?.setTitle("Log In")
        val db = databaseBuilder(applicationContext, AppDB::class.java, "app-database").allowMainThreadQueries().build()
        val userDao = db.userDao()
        var count = 0
        val logInButton=findViewById<Button>(R.id.logInButton)
        logInButton.setOnClickListener {
            try{
                val login_username=findViewById<EditText>(R.id.login_username)
                val tempUser = userDao.getUser(login_username.text.toString())
                val login_password=findViewById<EditText>(R.id.login_password)
                if(tempUser.password.equals(login_password.text.toString()))  {
                    Toast.makeText(baseContext,"Login successful",Toast.LENGTH_SHORT).show()
                    count = 0
                    val intent=Intent(this,MainActivity::class.java)
                    startActivity(intent)
                }
                else{
                    if(count<3){
                        Toast.makeText(baseContext,"Invalid Username Or Password",Toast.LENGTH_SHORT).show()
                        count++
                    }
                    else{
                        Toast.makeText(baseContext,"Failed, Log in disabled",Toast.LENGTH_SHORT).show()
                        logInButton.isEnabled = false
                    }
                }
            }
            catch (e: Exception) {
                Toast.makeText(baseContext, "Invalid Username", Toast.LENGTH_SHORT).show()
            }
        }
        val login_to_signup=findViewById<Button>(R.id.login_to_signup)
        login_to_signup.setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
        }
    }
}