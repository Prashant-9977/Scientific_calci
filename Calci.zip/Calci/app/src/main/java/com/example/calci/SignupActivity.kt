package com.example.calci
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import java.io.*

class SignupActivity : AppCompatActivity() {
    private lateinit var db: AppDB
    private val userFile = "user_data.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        supportActionBar?.title = "Sign Up"

        db = Room.databaseBuilder(applicationContext, AppDB::class.java, "app-database")
            .allowMainThreadQueries()
            .build()

        val userDao = db.userDao()

        val signUpButton = findViewById<Button>(R.id.signUpButton)
        signUpButton.setOnClickListener {
            val signUpPassword = findViewById<EditText>(R.id.signUp_password)
            val signUpUsername = findViewById<EditText>(R.id.signUp_username)

            if (signUpUsername.text.toString().isEmpty() || signUpPassword.text.toString().isEmpty()) {
                Toast.makeText(baseContext, "Please fill in username and password", Toast.LENGTH_SHORT).show()
            } else if (signUpPassword.text.toString().length < 8 || !isValidPassword(signUpPassword.text.toString())) {
                Toast.makeText(baseContext, "Invalid Password", Toast.LENGTH_SHORT).show()
            } else if (signUpUsername.text.toString().matches(Regex("^\\d.*"))) {
                Toast.makeText(baseContext, "Username cannot start with a number", Toast.LENGTH_SHORT).show()
            } else {
                val newUser = User(signUpUsername.text.toString(), signUpPassword.text.toString())

                if (isUserExist(newUser.username, userDao)) {
                    Toast.makeText(baseContext, "User already exists", Toast.LENGTH_SHORT).show()
                } else {
                    userDao.insert(newUser)
                    saveUserToFile(newUser)
                    Toast.makeText(baseContext, "Sign Up Successful", Toast.LENGTH_LONG).show()
                }
            }
        }

        val signUpToLogIn = findViewById<Button>(R.id.signUp_to_logIn)
        signUpToLogIn.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

    private fun isValidPassword(password: String?): Boolean {
        val passwordPattern = Regex("^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$")
        return passwordPattern.matches(password ?: "")
    }

    private fun isUserExist(username: String, userDao: UserDao): Boolean {
        val existingUser = userDao.getUser(username)
        return existingUser != null
    }

    private fun saveUserToFile(user: User) {
        val userString = "${user.username}:${user.password}"

        try {
            val fileOutputStream = openFileOutput(userFile, MODE_APPEND)
            val writer = OutputStreamWriter(fileOutputStream)
            writer.append(userString)
            writer.append("\n")
            writer.close()
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}
